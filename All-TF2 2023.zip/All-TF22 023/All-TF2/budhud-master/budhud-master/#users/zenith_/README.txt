For hudanimations_manifest to work properly you need to install it manually. Just replace the hudanimations_manifest.txt in \custom\budhud\scripts\ with the one here!
Sorry for the inconvienance!
-zen <3