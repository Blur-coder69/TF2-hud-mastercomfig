To use one of the custom features:

1. Open the folder of the feature you want to use
2. Copy the contents (resource, scripts, or sometimes both) to the root directory
3. Replace all the files when prompted
4. Run TF2